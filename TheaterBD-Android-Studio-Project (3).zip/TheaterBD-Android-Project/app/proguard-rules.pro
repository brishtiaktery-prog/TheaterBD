# Proguard rules for TheaterBD

# Keep WebView JavaScript interfaces
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep ViewBinding generated classes
-keep class net.theaterbd.app.databinding.** { *; }

# Keep native UI components
-keep public class * extends android.webkit.WebViewClient { *; }
-keep public class * extends android.webkit.WebChromeClient { *; }

# Preserve Line Numbers for Crash Reports
-keepattributes SourceFile,LineNumberTable
