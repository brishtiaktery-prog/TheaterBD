package net.theaterbd.app

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class TheaterChromeClient(
    private val activity: Activity,
    private val progressBar: ProgressBar?,
    private val fullscreenContainer: FrameLayout,
    private val mainContentContainer: View,
    private val onFileChooser: ((ValueCallback<Array<Uri>>?, WebChromeClient.FileChooserParams?) -> Boolean)? = null
) : WebChromeClient() {

    private var customView: View? = null
    private var customViewCallback: CustomViewCallback? = null
    private var originalOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var isFullscreen = false

    override fun onProgressChanged(view: android.webkit.WebView?, newProgress: Int) {
        super.onProgressChanged(view, newProgress)
        progressBar?.let {
            if (newProgress < 100) {
                it.visibility = View.VISIBLE
                it.progress = newProgress
            } else {
                it.visibility = View.GONE
            }
        }
    }

    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
        if (customView != null) {
            callback?.onCustomViewHidden()
            return
        }

        customView = view
        customViewCallback = callback
        isFullscreen = true

        // Keep screen on during video playback
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Store original orientation and rotate to sensor landscape for video
        originalOrientation = activity.requestedOrientation
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        // Hide main content & show fullscreen container
        mainContentContainer.visibility = View.GONE
        fullscreenContainer.visibility = View.VISIBLE
        fullscreenContainer.removeAllViews()
        fullscreenContainer.addView(
            view,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // Hide System UI (Status & Navigation bars) in immersive mode
        val window = activity.window
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onHideCustomView() {
        if (customView == null) return

        isFullscreen = false

        // Remove Keep Screen On flag
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Restore original orientation
        activity.requestedOrientation = originalOrientation

        // Restore views
        fullscreenContainer.removeAllViews()
        fullscreenContainer.visibility = View.GONE
        mainContentContainer.visibility = View.VISIBLE

        // Restore System UI
        val window = activity.window
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())

        customViewCallback?.onCustomViewHidden()
        customView = null
        customViewCallback = null
    }

    fun isCustomViewShowing(): Boolean = isFullscreen

    fun exitFullscreen() {
        if (isFullscreen) {
            onHideCustomView()
        }
    }

    override fun onShowFileChooser(
        webView: android.webkit.WebView?,
        filePathCallback: ValueCallback<Array<Uri>>?,
        fileChooserParams: FileChooserParams?
    ): Boolean {
        return onFileChooser?.invoke(filePathCallback, fileChooserParams) ?: false
    }
}
