package net.theaterbd.app

import android.annotation.SuppressLint
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.widget.Button
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import net.theaterbd.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    companion object {
        const val TARGET_URL = "http://198.18.18.18/"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var chromeClient: TheaterChromeClient
    private lateinit var webClient: TheaterWebViewClient

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var fileChooserLauncher: ActivityResultLauncher<Intent>

    private var isTvDevice: Boolean = false
    private var isFirstLoad = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Detect if device is Android TV / Google TV
        isTvDevice = checkIsTvDevice()
        
        if (isTvDevice) {
            // Android TV devices always run in landscape
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            // Disable swipe-to-refresh on TV to avoid D-pad conflict
            binding.swipeRefreshLayout.isEnabled = false
        } else {
            // Mobile: pull-to-refresh enabled
            binding.swipeRefreshLayout.setOnRefreshListener {
                binding.webView.reload()
            }
            binding.swipeRefreshLayout.setColorSchemeResources(
                R.color.theaterbd_primary,
                R.color.theaterbd_accent
            )
        }

        // Setup File Chooser Launcher
        setupFileChooser()

        // Setup Error View Retry & Exit buttons
        setupErrorViewButtons()

        // Setup Intelligent Back Press Handling
        setupBackNavigation()

        // Setup WebView
        setupWebView()

        // Load URL or restore state
        if (savedInstanceState != null) {
            binding.webView.restoreState(savedInstanceState)
        } else {
            showLoading(true)
            binding.webView.loadUrl(TARGET_URL)
        }
    }

    private fun checkIsTvDevice(): Boolean {
        val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        if (uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION) {
            return true
        }
        val pm = packageManager
        return pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
               pm.hasSystemFeature(PackageManager.FEATURE_TELEVISION)
    }

    private fun setupFileChooser() {
        fileChooserLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            val data = result.data
            val results: Array<Uri>? = when {
                result.resultCode != RESULT_OK -> null
                data == null -> null
                data.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                data.data != null -> arrayOf(data.data!!)
                else -> null
            }
            fileUploadCallback?.onReceiveValue(results)
            fileUploadCallback = null
        }
    }

    private fun setupErrorViewButtons() {
        val btnRetry = binding.root.findViewById<Button>(R.id.btnRetry)
        val btnExit = binding.root.findViewById<Button>(R.id.btnExit)

        btnRetry?.setOnClickListener {
            hideErrorView()
            showLoading(true)
            binding.webView.loadUrl(TARGET_URL)
        }

        btnExit?.setOnClickListener {
            showExitConfirmationDialog()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    // 1. If Fullscreen video is active, exit fullscreen
                    chromeClient.isCustomViewShowing() -> {
                        chromeClient.exitFullscreen()
                    }
                    // 2. If WebView can go back, navigate back
                    binding.webView.canGoBack() -> {
                        binding.webView.goBack()
                    }
                    // 3. Otherwise, confirm before exiting
                    else -> {
                        showExitConfirmationDialog()
                    }
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings

        // 1. Core Web Capabilities
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true

        // 2. HTML5 Video & Autoplay
        settings.mediaPlaybackRequiresUserGesture = false
        settings.setSupportZoom(true)
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true

        // 3. Cache & Performance
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        
        // 4. Mixed Content (Allow cleartext HTTP connection to 198.18.18.18)
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        // 5. User-Agent
        val defaultUserAgent = settings.userAgentString
        val deviceType = if (isTvDevice) "AndroidTV" else "AndroidMobile"
        settings.userAgentString = "$defaultUserAgent TheaterBD-App/1.0.0 ($deviceType)"

        // 6. Cookies Setup
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        // 7. Focus & TV Remote Navigation
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true
        webView.requestFocus()

        // 8. Custom Clients
        chromeClient = TheaterChromeClient(
            activity = this,
            progressBar = binding.progressBar,
            fullscreenContainer = binding.fullscreenContainer,
            mainContentContainer = binding.mainContentContainer,
            onFileChooser = { callback, params ->
                fileUploadCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                try {
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    fileUploadCallback = null
                    false
                }
            }
        )
        webView.webChromeClient = chromeClient

        webClient = TheaterWebViewClient(
            context = this,
            onPageLoadStarted = {
                hideErrorView()
                if (isFirstLoad) {
                    showLoading(true)
                }
            },
            onPageLoadFinished = {
                showLoading(false)
                isFirstLoad = false
                binding.swipeRefreshLayout.isRefreshing = false
            },
            onErrorReceived = { isMainFrame, errorCode, desc ->
                if (isMainFrame) {
                    showErrorView()
                }
            }
        )
        webView.webViewClient = webClient

        // 9. Download handling
        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            DownloadHelper.handleDownload(
                context = this,
                url = url,
                userAgent = userAgent,
                contentDisposition = contentDisposition,
                mimeType = mimetype
            )
        }
    }

    private fun showLoading(visible: Boolean) {
        binding.loadingOverlay.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun showErrorView() {
        showLoading(false)
        binding.swipeRefreshLayout.isRefreshing = false
        val errorLayout = binding.root.findViewById<View>(R.id.layoutOfflineError)
        errorLayout?.visibility = View.VISIBLE
        binding.webView.visibility = View.GONE

        // Auto-focus Retry button for Android TV remote
        val btnRetry = binding.root.findViewById<Button>(R.id.btnRetry)
        btnRetry?.requestFocus()
    }

    private fun hideErrorView() {
        val errorLayout = binding.root.findViewById<View>(R.id.layoutOfflineError)
        errorLayout?.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE
    }

    private fun showExitConfirmationDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_exit, null)
        val dialog = AlertDialog.Builder(this, R.style.Theme_TheaterBD_Dialog)
            .setView(dialogView)
            .create()

        dialogView.findViewById<Button>(R.id.btnCancelExit)?.setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<Button>(R.id.btnConfirmExit)?.setOnClickListener {
            dialog.dismiss()
            finish()
        }

        dialog.show()

        // Focus cancel by default on TV
        dialogView.findViewById<Button>(R.id.btnCancelExit)?.requestFocus()
    }

    // Android TV Remote Key Handling
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    // Let WebView handle click on focused HTML element
                    if (binding.webView.hasFocus()) {
                        return super.dispatchKeyEvent(event)
                    }
                }
                KeyEvent.KEYCODE_BACK -> {
                    // OnBackPressedDispatcher takes care of back handling
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // State Preservation
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        binding.webView.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        binding.webView.restoreState(savedInstanceState)
    }

    override fun onPause() {
        super.onPause()
        binding.webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
    }

    override fun onDestroy() {
        // Prevent WebView memory leaks
        binding.rootContainer.removeAllViews()
        binding.webView.apply {
            stopLoading()
            clearHistory()
            clearCache(false)
            destroy()
        }
        super.onDestroy()
    }
}
