package net.theaterbd.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient

class TheaterWebViewClient(
    private val context: Context,
    private val onPageLoadStarted: () -> Unit,
    private val onPageLoadFinished: () -> Unit,
    private val onErrorReceived: (isMainFrame: Boolean, errorCode: Int, description: String) -> Unit
) : WebViewClient() {

    companion object {
        const val THEATERBD_HOST = "198.18.18.18"
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val uri = request?.url ?: return false
        val scheme = uri.scheme?.lowercase() ?: return false

        // Handle external protocols safely
        if (scheme == "tel" || scheme == "mailto" || scheme == "sms" || scheme == "intent" || scheme == "market") {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return true
        }

        // Keep TheaterBD navigation strictly inside the WebView
        val host = uri.host
        if (host == THEATERBD_HOST || host == null) {
            return false
        }

        // External HTTP/HTTPS links
        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        onPageLoadStarted()
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        // Flush cookies to persistent disk storage
        CookieManager.getInstance().flush()
        onPageLoadFinished()
    }

    override fun onReceivedError(
        view: WebView?,
        request: WebResourceRequest?,
        error: WebResourceError?
    ) {
        super.onReceivedError(view, request, error)
        val isMainFrame = request?.isForMainFrame ?: true
        val errorCode = error?.errorCode ?: -1
        val description = error?.description?.toString() ?: "Network error"
        if (isMainFrame) {
            onErrorReceived(true, errorCode, description)
        }
    }

    override fun onReceivedHttpError(
        view: WebView?,
        request: WebResourceRequest?,
        errorResponse: WebResourceResponse?
    ) {
        super.onReceivedHttpError(view, request, errorResponse)
        val statusCode = errorResponse?.statusCode ?: 200
        val isMainFrame = request?.isForMainFrame ?: true
        if (isMainFrame && (statusCode >= 400)) {
            onErrorReceived(true, statusCode, "HTTP Error $statusCode")
        }
    }
}
